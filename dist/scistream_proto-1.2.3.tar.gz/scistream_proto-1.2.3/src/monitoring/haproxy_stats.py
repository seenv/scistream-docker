import subprocess
import pandas as pd
from prettytable import PrettyTable

def get_haproxy_stats():
    try:
        # Run the HAProxy stats command and capture the output
        result = subprocess.run(
            'echo "show stat" | socat /tmp/haproxy.sock stdio',
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            shell=True
        )
        print("the result in the get_hproxy_stat :", result.stdout)
        if result.returncode != 0:
            raise Exception(f"Error executing command: {result.stderr.strip()}")
        #return result.stdout
    except Exception as e:
        print(f"Failed to fetch HAProxy stats: {e}")
        return ""

def parse_haproxy_stats(output):
    if not output:
        print("No stats to parse!")
        return None

    lines = output.strip().split("\n")

    # First line contains headers
    headers = lines[0][2:].split(",")  # Remove "# " prefix and split by commas
    rows = [line.split(",") for line in lines[1:]]
    #print ("output header without sharp sign: ",headers)
    # Create a DataFrame for better manipulation
    df = pd.DataFrame(rows, columns=headers)
    return df

def display_table(df, filter_proxy=None):
    if df is None:
        print("No data available to display!")
        return

    table = PrettyTable()
    table.field_names = df.columns.tolist()

    # Filter rows by proxy name if required
    if filter_proxy:
        df = df[df['pxname'] == filter_proxy]

    for _, row in df.iterrows():
        table.add_row(row.tolist())

    print(table)

def main():
    # Fetch the stats
    haproxy_output = get_haproxy_stats()
    print("haproxy_output", haproxy_output) 
    # Parse the stats
    df = parse_haproxy_stats(haproxy_output)
    print("df is ", df)

    # Display all stats in a table
    print("All HAProxy Stats:")
    display_table(df)

    # Display stats filtered by frontend/backend name
    print("\nFiltered Stats for 'my_frontend_1':")
    display_table(df, filter_proxy="my_frontend_1")

if __name__ == "__main__":
    main()